<?php

require_once 'classes/Session.php'; 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');
include('classes/Database.php');
include('classes/Event.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Initialize Database and Event classes
$db = new Database();
$event = new Event($db);

// Fetch user's events
try {
    $events = $event->getEventsByUser($user_id);
} catch (Exception $e) {
    die('Error fetching events: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Event Management</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .custom-btn {
      background: #a777e3;
      border: none;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
    }
    .btn-warning {
      background: #f0ad4e;
      border: none;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
    }
    .btn-danger {
      background: #d9534f;
      border: none;
      color: white;
      padding: 5px 10px;
      border-radius: 5px;
    }
    .manage-events-heading {
      text-align: center;
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 10px;
    }
    .manage-events-subtext {
      text-align: center;
      font-style: italic;
      color: #666;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.php">Opal</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li class="active"><a href="eventManagement.php">Manage Events</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php
        if (isset($_SESSION['username'])) {
          echo '<li><a href="#"><span class="glyphicon glyphicon-user"></span> ' . htmlspecialchars($_SESSION['username']) . '</a></li>';
          echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
        } else {
          echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>

  <div class="container mt-5">
    <div class="manage-events-heading">
      Manage Your Events
    </div>
    <div class="manage-events-subtext">
      You can always count on Opal to manage and create events.
    </div>

    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Title</th>
          <th>Description</th>
          <th>Date</th>
          <th>Location</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($events): ?>
          <?php foreach ($events as $event): ?>
            <tr>
              <td><?php echo htmlspecialchars($event['event_name']); ?></td>
              <td><?php echo htmlspecialchars($event['description']); ?></td>
              <td><?php echo htmlspecialchars($event['date_and_time']); ?></td>
              <td><?php echo htmlspecialchars($event['location']); ?></td>
              <td>
                <a href="editEvent.php?id=<?php echo $event['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                <a href="deleteEvent.php?id=<?php echo $event['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this event?');">Delete</a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" class="text-center">No events posted.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
    <a href="addEvent.php" class="btn custom-btn">Add Event</a>
  </div>
</body>
</html>
