<?php
require_once 'classes/Session.php'; 
session_start();
include('config.php');
include('classes/Database.php');
include('classes/User.php');

$db = new Database();
$user = new User($db); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $identifier = $_POST['username_email']; 
    $password = $_POST['password'];
    var_dump($password);

    // Validate input
    if (empty($identifier) || empty($password)) {
        $_SESSION['login_error'] = "Username/Email and password are required.";
        header('Location: login.php');
        exit();
    }
    // Check if user exists
    $userData = $user->getUserByUsernameOrEmail($identifier);

    if (!$userData) {
        $_SESSION['login_error'] = "Invalid username/email or password.";

        header('Location: login.php');
        exit();
    }
    var_dump($userData);
    // Verify the password
    if (password_verify($password, $userData['password'])) {
        
        $_SESSION['user_id'] = $userData['id'];
        $_SESSION['username'] = $userData['username']; 
        header('Location: index.php'); 
        var_dump($_SESSION);
        
    } else {
        
        $_SESSION['login_error'] = "Invalid username/email or password.";
        header('Location: login.php');
        exit();
    }
} else {
    header('Location: login.php');
    exit();
}