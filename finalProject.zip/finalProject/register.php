<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Opal</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>

                    <li class="nav-item active">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5 vh-100">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card my-auto shadow">
                    <div class="card-header text-center bg-primary text-white">
                        Register to Opal
                    </div>
                    <div class="card-body">
                        <?php if (isset($_SESSION['registration_error'])): ?>
                            <div class="alert alert-danger text-center">
                                <?php echo $_SESSION['registration_error']; ?>
                            </div>
                            <?php unset($_SESSION['registration_error']); ?>
                        <?php endif; ?>
                        <form action="registerHandler.php" method="POST">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <input type="submit" class="btn btn-primary btn-block w-100 mt-3" value="Register">
                        </form>
                    </div>
                    <div class="card-footer text-center">
                        <small>&copy; RafaelJr-46008</small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (isset($_SESSION['registration_success'])): ?>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="alert alert-primary text-center">
                        <?php echo $_SESSION['registration_success']; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php unset($_SESSION['registration_success']); ?>
    <?php endif; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
