<?php
require_once 'classes/Session.php'; 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');
include('classes/Database.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $eventId = $_GET['id'];

    try {
   
        $db = new Database();
        $pdo = $db->getPdo();

     
        $sql = "DELETE FROM events WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$eventId]);

        $rowCount = $stmt->rowCount();
        if ($rowCount > 0) {
            header('Location: eventManagement.php');
            exit();
        } else {
            echo "Event not found or already deleted.";
        }
    } catch (PDOException $e) {
        echo "Error deleting event: " . $e->getMessage();
    }
} else {
    echo "Invalid event ID.";
}
?>
