<?php
require_once 'classes/Session.php'; 
session_start();
session_unset();
session_destroy();
header("Location: login.php");
exit();
?>
