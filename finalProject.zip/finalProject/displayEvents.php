<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Available Events</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .toggle-switch {
      position: relative;
      display: inline-block;
      width: 34px;
      height: 20px;
    }

    .toggle-switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      transition: .4s;
      border-radius: 34px;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 14px;
      width: 14px;
      left: 3px;
      bottom: 3px;
      background-color: white;
      transition: .4s;
      border-radius: 50%;
    }

    input:checked + .slider {
      background-color: #007bff;
    }

    input:checked + .slider:before {
      transform: translateX(14px);
    }

    .manage-events-heading {
      text-align: center;
      font-size: 28px;
      font-weight: bold;
      margin-bottom: 10px;
    }

    .manage-events-subtext {
      text-align: center;
      font-style: italic;
      color: #666;
      margin-bottom: 20px;
    }
  </style>
  <script>
    $(document).ready(function() {
      $('.attend-toggle').change(function() {
        var eventId = $(this).data('event-id');
        var isAttended = $(this).is(':checked') ? 1 : 0;

        $.ajax({
          url: 'updateAttendance.php', 
          method: 'POST',
          data: { event_id: eventId, attended: isAttended },
          success: function(response) {
            if (response !== 'success') {
              alert('Failed to update attendance.');
              // Revert the checkbox state if the update failed
              $('.attend-toggle[data-event-id="' + eventId + '"]').prop('checked', !isAttended);
            }
          },
          error: function() {
            alert('Error: Server error.');
            // Revert the checkbox state if there is a server error
            $('.attend-toggle[data-event-id="' + eventId + '"]').prop('checked', !isAttended);
          }
        });
      });
    });
  </script>
</head>
<body>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.php">Opal</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li class="active"><a href="displayEvents.php">Available Events</a></li>
        <li><a href="eventManagement.php">Create Events</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php
        require_once 'classes/Session.php'; 
        session_start();
        if (isset($_SESSION['username'])) {
          echo '<li><a href="#"><span class="glyphicon glyphicon-user"></span> ' . htmlspecialchars($_SESSION['username']) . '</a></li>';
          echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
        } else {
          echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>

  <div class="container mt-5">
    <div class="manage-events-heading">
      Available Events
    </div>
    <div class="manage-events-subtext">
      Click the toggle to confirm which events you are going to.
    </div>

    <?php
    include('config.php');
    include('classes/Database.php');
    include('classes/Event.php');

    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
      header("Location: login.php");
      exit();
    }

    $currentUserId = $_SESSION['user_id'];

    try {
     
      $db = new Database();
      $sql = "SELECT * FROM events WHERE user_id != ?";
      $events = $db->query($sql, [$currentUserId])->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
      echo "Error fetching events: " . $e->getMessage();
      exit();
    } catch (Exception $e) {
      echo "Error: " . $e->getMessage();
      exit();
    }

    if (!empty($events)): ?>
      <ul class="list-group">
        <?php foreach ($events as $event): ?>
          <li class="list-group-item">
            <h5><?php echo htmlspecialchars($event['event_name']); ?></h5>
            <p><?php echo htmlspecialchars($event['description']); ?></p>
            <p><strong>Date:</strong> <?php echo htmlspecialchars($event['date_time']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></p>
            <?php
            $attendedClass = ''; // Default not attended
            if (isset($_SESSION['attended_events']) && in_array($event['id'], $_SESSION['attended_events'])) {
              $attendedClass = 'checked';
            }
            ?>
            <label class="toggle-switch">
              <input type="checkbox" class="attend-toggle" data-event-id="<?php echo $event['id']; ?>" <?php echo $attendedClass; ?>>
              <span class="slider"></span>
            </label>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p>No events available.</p>
    <?php endif; ?>
  </div>
</body>
</html>
