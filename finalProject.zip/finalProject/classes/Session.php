<?php

class Session {
    
    public static function startSession() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
    }
    
    public static function endSession() {
        session_destroy();
    }
    
    public static function getSessionData($key) {
        self::startSession();
        if (isset($_SESSION[$key])) {
            return $_SESSION[$key];
        }
        return null;
    }
    
    public static function setSessionData($key, $value) {
        self::startSession();
        $_SESSION[$key] = $value;
    }
    
    public static function unsetSessionData($key) {
        self::startSession();
        if (isset($_SESSION[$key])) {
            unset($_SESSION[$key]);
        }
    }
    
    public static function getSessionID() {
        self::startSession();
        return session_id();
    }
    
    public static function regenerateSessionID() {
        self::startSession();
        session_regenerate_id(true);
    }
    
    // Other session-related functions can be added as needed
    
}

?>
