<?php
class Event {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function addEvent($userId, $event_name, $description, $datetime, $location) {
        $sql = "INSERT INTO events (user_id, event_name, description, date_and_time, location) VALUES (:user_id, :event_name, :description, :date_and_time, :location)";
        $this->db->execute($sql, [
            ':user_id' => $userId,
            ':event_name' => $event_name,
            ':description' => $description,
            ':date_and_time' => $datetime,
            ':location' => $location
        ]);
    }

    public function getEventsByUser($userId) {
        $sql = "SELECT * FROM events WHERE user_id = :user_id";
        return $this->db->fetchAll($sql, [':user_id' => $userId]);
    }
}