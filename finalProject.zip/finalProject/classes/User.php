<?php
class User {
    private $db;

    public function __construct(Database $db) {
        $this->db = $db;
    }

    public function register($username, $email, $password) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
        $params = [
            ':username' => $username,
            ':email' => $email,
            ':password' => $hashedPassword,
        ];
        
        try {
            $this->db->execute($sql, $params);
            return true; // Registration successful
        } catch (PDOException $e) {
            // Handle error or log it
            return false; // Registration failed
        }
    }

    public function userExists($username, $email) {
        $sql = "SELECT * FROM users WHERE username = :username OR email = :email";
        $params = [
            ':username' => $username,
            ':email' => $email,
        ];
        
        try {
            $stmt = $this->db->execute($sql, $params);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Handle error or log it
            return false; // Error occurred
        }
    }
    public function getUserByUsernameOrEmail($identifier) {
        $sql = "SELECT * FROM users WHERE username = :identifier OR email = :identifier";
        $params = [
            ':identifier' => $identifier,
        ];
        
        try {
            $stmt = $this->db->execute($sql, $params);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Handle error or log it
            return false; // Error occurred
        }
    }
}
?>
