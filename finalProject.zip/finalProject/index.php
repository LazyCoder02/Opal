<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Opal - Home</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .custom-card {
      background: linear-gradient(135deg, #6e8efb, #a777e3);
      color: white;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      overflow: hidden;
      height: 400px; 
      display: flex;
      flex-direction: column;
    }
    .custom-card h5 {
      font-size: 1.5em;
    }
    .custom-card img {
      width: 100%;
      height: 200px; 
      object-fit: cover;
    }
    .custom-card-body {
      padding: 15px;
      text-align: center;
      flex-grow: 1;
    }
    .custom-btn {
      background: #a777e3;
      border: none;
      padding: 10px 20px;
      font-size: 1em;
      color: white;
      border-radius: 5px;
    }
    .welcome-text {
      text-align: center;
      margin-bottom: 30px;
      font-size: 2em;
      color: #6e8efb;
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.php">Opal</a>
      </div>
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php
        require_once 'classes/Session.php'; 
        session_start();
        if (isset($_SESSION['username'])) {
          echo '<li><a href="#"><span class="glyphicon glyphicon-user"></span> ' . htmlspecialchars($_SESSION['username']) . '</a></li>';
          echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
        } else {
          echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>

  <div class="container mt-5">
    <div class="welcome-text">Welcome to Opal! Discover and Create Events Easily</div>
    <div class="row">
      <div class="col-md-6">
        <div class="card custom-card">
          <img src="pictures/event1.png" alt="Event">
          <div class="card-body custom-card-body">
            <h5 class="card-title">View the events waiting for you</h5>
            <p class="card-text">Discover events posted by other users.</p>
            <a href="displayEvents.php" class="btn custom-btn">See Events</a>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card custom-card">
          <img src="pictures/setEvent.png" alt="Event">
          <div class="card-body custom-card-body">
            <h5 class="card-title">Set your upcoming events with ease</h5>
            <p class="card-text">Create and manage your own events easily.</p>
            <a href="eventManagement.php" class="btn custom-btn">Create Events</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
