<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <style>
        body {
            background-color: #f0f0f0; 
        }

        .card {
            margin-top: 20px;
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
        }

        .card-header {
            background-color: #007bff;
            color: white;
            font-weight: bold;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .center-button {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Opal</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <?php
                require_once 'classes/Session.php';
                if (isset($_SESSION['registration_success'])) {
                    echo "<div class='alert alert-primary text-center' role='alert'>{$_SESSION['registration_success']}</div>";
                    unset($_SESSION['registration_success']);
                }
                ?>
                <div class="card my-auto shadow">
                    <div class="card-header text-center">
                        Login to Opal
                    </div>
                    <div class="card-body">
                        <form action="loginHandler.php" method="POST">
                            <div class="form-group">
                                <label for="username_email">Username or Email</label>
                                <input type="text" class="form-control" id="username_email" name="username_email" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <div class="center-button">
                                <button type="submit" class="btn btn-primary btn-block w-50 mt-3" value="Login">Login</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-center">
                        <small>If you are not registered, <a href="register.php">click here</a> to register.</small>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</body>
</html>
