<?php
require_once 'classes/Session.php'; 
session_start();
include('config.php');
include('classes/Database.php');

if (!isset($_SESSION['user_id'])) {
    echo 'error';
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['event_id']) && isset($_POST['attended'])) {
    $userId = $_SESSION['user_id'];
    $eventId = $_POST['event_id'];
    $attended = $_POST['attended'];

    try {
        $db = new Database();
        $pdo = $db->getPdo();

        // Update the attendance status
        if ($attended) {
            $sql = "INSERT INTO user_events (user_id, event_id) VALUES (?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$userId, $eventId]);
        } else {
            $sql = "DELETE FROM user_events WHERE user_id = ? AND event_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$userId, $eventId]);
        }

        echo 'success';
    } catch (PDOException $e) {
        echo 'error: ' . $e->getMessage();
    }
} else {
    echo 'error';
}
?>
