<?php

require_once 'classes/Session.php'; 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'db_connection.php';


if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $eventId = $_GET['id'];
    
    $sql = "SELECT * FROM events WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$eventId]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($event) {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $event_name = $_POST['event_name'];
            $description = $_POST['description'];
            $event_datetime = !empty($_POST['event_datetime']) ? $_POST['event_datetime'] : null;
            $location = $_POST['location'];
            
            $updateSql = "UPDATE events SET event_name = ?, description = ?, date_and_time = ?, location = ? WHERE id = ?";
            $updateStmt = $pdo->prepare($updateSql);
            $updateResult = $updateStmt->execute([$event_name, $description, $event_datetime, $location, $eventId]);
            
            if ($updateResult) {
                header("Location: eventManagement.php");
                exit();
            } else {
                echo "Update failed. Please try again.";
            }
        }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Event</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>
        .custom-btn {
            background: #a777e3;
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .btn-secondary {
            background: #6c757d;
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .edit-heading {
            text-align: center;
            font-weight: bold;
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .edit-subtext {
            text-align: center;
            font-style: italic;
            color: #666;
            margin-bottom: 20px; 
        }
    </style>
    <script>
        function confirmUpdate() {
            return confirm('Do you want to update this event?');
        }
    </script>
</head>
<body>
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php">Opal</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li class="active"><a href="eventManagement.php">Manage Events</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <?php
                if (isset($_SESSION['username'])) {
                    echo '<li><a href="#"><span class="glyphicon glyphicon-user"></span> ' . htmlspecialchars($_SESSION['username']) . '</a></li>';
                    echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
                } else {
                    echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
                }
                ?>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="edit-heading">
            Edit your event carefully to meet your needs
        </div>
        <div class="edit-subtext">
            Opal users are very picky when choosing an event
        </div>

        <form action="" method="post" class="form-horizontal" onsubmit="return confirmUpdate();">
            <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
            <div class="form-group">
                <label for="event_name" class="col-sm-2 control-label">Title:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="event_name" name="event_name" value="<?php echo htmlspecialchars($event['event_name']); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="description" class="col-sm-2 control-label">Description:</label>
                <div class="col-sm-10">
                    <textarea class="form-control" id="description" name="description" required><?php echo htmlspecialchars($event['description']); ?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="event_datetime" class="col-sm-2 control-label">Date and Time:</label>
                <div class="col-sm-10">
                    <input type="datetime-local" class="form-control" id="event_datetime" name="event_datetime" value="<?php echo !empty($event['date_and_time']) ? date('Y-m-d\TH:i', strtotime($event['date_and_time'])) : ''; ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="location" class="col-sm-2 control-label">Location:</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($event['location']); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn custom-btn">Update Event</button>
                    <a href="eventManagement.php" class="btn btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
<?php
        exit(); 
    } else {
        echo "Event not found.";
    }
} else {
    echo "Invalid event ID.";
}
?>
