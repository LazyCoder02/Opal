<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include('config.php');
include('classes/Database.php');
include('classes/User.php');

$db = new Database();

$user = new User($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

   

    // Validate input
    if (empty($username) || empty($email) || empty($password)) {
        $_SESSION['registration_error'] = "All fields are required.";
        header('Location: register.php');
        exit();
    }

    // Check if username or email already exists
    if ($user->userExists($username, $email)) {
        $_SESSION['registration_error'] = "Username or Email already exists.";
        header('Location: register.php');
        exit();
    }


    // Register the user
    if ($user->register($username, $email, $password)) {
        $_SESSION['registration_success'] = "Registration successful! You can now log in.";
        header('Location: login.php'); // Redirect to login page
        exit();
    } else {
        $_SESSION['registration_error'] = "Registration failed. Please try again.";
        header('Location: register.php');
        exit();
    }
} else {
    header('Location: register.php');
    exit();
}