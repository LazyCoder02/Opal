<?php
require_once 'classes/Session.php'; 
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

include('config.php');
include('classes/Database.php');
include('classes/Event.php');


$error = '';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate inputs
    $event_name = htmlspecialchars($_POST['title']);
    $description = htmlspecialchars($_POST['description']);
    $datetime = htmlspecialchars($_POST['date_and_time']);
    $location = htmlspecialchars($_POST['location']);

    if (empty($event_name) || empty($description) || empty($datetime) || empty($location)) {
        $error = "All fields are required.";
    } else {
        $db = new Database();
        $event = new Event($db);

        try {
            $event->addEvent($_SESSION['user_id'], $event_name, $description, $datetime, $location);
            $_SESSION['event_success'] = "Event added successfully!";
            header('Location: eventManagement.php');
            exit();
        } catch (Exception $e) {
            $error = "Error adding event: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Event</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <style>
    .center-content {
      text-align: center;
    }
    .catchy-subtext {
      font-style: italic;
      color: #666;
      font-size: 1.2em;
      margin-bottom: 20px;
    }
    .custom-btn {
      background-color: #6c757d; 
      border-color: #6c757d; 
    }
    .custom-btn:hover {
      background-color: #5a6268;
      border-color: #5a6268;
    }
  </style>
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="index.php">Opal</a>
      </div>
      <ul class="nav navbar-nav">
        <li><a href="index.php">Home</a></li>
        <li><a href="eventManagement.php">Manage Events</a></li>
        <li class="active"><a href="addEvent.php">Add Event</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <?php
        if (isset($_SESSION['username'])) {
          echo '<li><a href="#"><span class="glyphicon glyphicon-user"></span> ' . htmlspecialchars($_SESSION['username']) . '</a></li>';
          echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
        } else {
          echo '<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>';
        }
        ?>
      </ul>
    </div>
  </nav>

  <div class="container mt-5">
    <div class="center-content">
      <h1>Add an Event</h1>
      <p class="catchy-subtext">Create a memorable event experience with Opal!</p>
    </div>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
      <div class="form-group">
        <label for="title">Event Name</label>
        <input type="text" class="form-control" id="title" name="title" value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" required>
      </div>
      <div class="form-group">
        <label for="description">Description</label>
        <textarea class="form-control" id="description" name="description" required><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
      </div>
      <div class="form-group">
        <label for="datetime">Date and Time</label>
        <input type="datetime-local" class="form-control" id="datetime" name="date_and_time" value="<?php echo isset($_POST['date_and_time']) ? htmlspecialchars($_POST['date_and_time']) : ''; ?>" required>
      </div>
      <div class="form-group">
        <label for="location">Location</label>
        <input type="text" class="form-control" id="location" name="location" value="<?php echo isset($_POST['location']) ? htmlspecialchars($_POST['location']) : ''; ?>" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block custom-btn">Add Event</button>
    </form>
  </div>
</body>
</html>
